/*
 * Solution to Exercise 4.2
 *
 * Calculates the velocity and position of a free-falling object in a
 * vacuum subject to the influence of gravity. The object is initially at a
 * prescribed height and with zero velocity.
 *
 */

#include <iostream>
#include <string>
using namespace std;

int main() {
    string       input =  "";        /// Temporary input buffer
    const double g     = -9.8;       /// Acceleration due to gravity
    double       h     =  0.0;       /// Object height
    double       T     =  0.0;       /// Fall time
    double       V;
    double       d;

    // Request object height
    cout << "Please enter object height: ";

    // Get string input from user (up to next press of <enter> key)
    getline (cin, input);

    // Convert input to double-precision floating-point value
    h = stod(input);

    // Request fall time
    cout << "Please enter time of fall: ";

    // Get string input
    getline (cin, input);

    // Convert to a double
    T = stod(input);

    // Calculate velocity and distance fallen
    V = g * T;
    d = g * T * T / 2.0  +  h;

    // Write out result
    cout << "Object velocity: " << V << " m/s" << endl;
    cout << "Position:        " << d << " m"   << endl;

    // Return success
    return 0;
}

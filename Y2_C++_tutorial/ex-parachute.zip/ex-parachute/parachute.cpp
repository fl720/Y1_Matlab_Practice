/*
 * Solution to Exercise 4.3.
 *
 * Calculates the velocity of a parachutist at 3s, 5s and 10s as well as the
 * terminal velocity, given the mass and drag coefficient.
 *
 */

#include <iostream>
#include <string>

// Include 'cmath' header for 'exp' math function.
#include <cmath>

using namespace std;

int main() {
    string       input = "";        /// Temporary input buffer
    const double g     = 9.8;       /// Acceleration due to gravity
    double       m     = 0.0;       /// Her mass
    double       c     = 0.0;       /// Drag coefficient
    double       v3, v5, v10;

    // Request parachutists mass
    cout << "Please enter parachutists mass: ";

    // Get string input from user (up to next press of <enter> key)
    getline (cin, input);

    // Convert input to double-precision floating-point value
    m = stod(input);

    // Request drag coefficient
    cout << "Please enter drag coefficient: ";

    // Get string input
    getline (cin, input);

    // Convert to a double
    c = stod(input);

    // Calculate velocity
    v3  = m * g / c * ( exp( -(c * 3.0  / m) ) - 1.0 );
    v5  = m * g / c * ( exp( -(c * 5.0  / m) ) - 1.0 );
    v10 = m * g / c * ( exp( -(c * 10.0 / m) ) - 1.0 );

    // Write out result
    cout << "Vertical velocity (3 s):  " << v3  << " m/s" << endl;
    cout << "Vertical velocity (5 s):  " << v5  << " m/s" << endl;
    cout << "Vertical velocity (10 s): " << v10 << " m/s" << endl;

    // Calculate terminal velocity
    cout << "Terminal velocity is:     " << -m*g/c << " m/s" << endl;

    // Return success
    return 0;
}

/*
 * Solution to Exercise 3.2
 *
 * Applies operator precedence.
 *
 */

#include <iostream>
using namespace std;

int main() {
    int a = 2;
    int b = 5;
    int c = 4;

    int result = a + b * c / a * ( b - c ) + b % c;
    cout << "Result is " << result << endl;

    return 0;
}

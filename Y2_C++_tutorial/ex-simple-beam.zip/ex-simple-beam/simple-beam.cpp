/*
 * Solution to Exercise 4.4
 *
 * Calculates the deflection at the mid-point of a simply supported beam.
 */

#include <iostream>
#include <string>
using namespace std;

int main() {
    string       input = "";        /// Temporary input buffer
    double       L     = 0.0;       /// Beam length
    double       E     = 0.0;       /// Young's modulus
    double       I     = 0.0;       /// Second moment of area
    double       w     = 0.0;       /// Magnitude of distributed load
    double       x     = 0.0;       /// Midpoint of beam 
    double       y;                 /// Calculated deflection at x

    // Request beam length
    cout << "Please enter the length of the beam (m): ";
    getline (cin, input);
    L = stod(input);

    // Request Young's modulus
    cout << "Please enter the Young's modulus (Pa): ";
    getline (cin, input);
    E = stod(input);

    // Request second moment of area
    cout << "Please enter the second moment of area (m^4): ";
    getline (cin, input);
    I = stod(input);

    // Request magnitude of load
    cout << "Please enter the magnitude of the distributed load (N/m): ";
    getline (cin, input);
    w = stod(input);

    // Calculate mid-point and its deflection
    x = L/2.0;
    y = -w / (24.0 * E * I) * (x * (x*x * (x - 2*L) + L*L*L));
    // Note: by factorizing this expression, we reduce the number of operations
    // and do not call the expensive power function, which is unnecessary for
    // small integer powers.

    // Print result
    cout << "Mid-point is  x = " << x << endl;
    cout << "Deflection is y = " << y << endl;

    // Return success
    return 0;
}

/*
 * Solution to Exercise 4.1
 *
 * Calculate the volume and surface area of a sphere.
 *
 */

#include <iostream>
#include <string>
#include <sstream>
#include <cmath>                    // Include cmath for M_PI constant
using namespace std;

int main() {
    const double pi    = M_PI;      /// Value of PI defined by C++
    string       input = "";        /// Temporary input buffer
    double       r     = 0.0;       /// Sphere radius
    double       A     = 0.0;       /// Sphere area
    double       V     = 0.0;       /// Sphere volume

    // Request radius
    cout << "Please enter radius of sphere: ";

    // Get string input from user (up to next press of <enter> key)
    getline (cin, input);

    // Try to convert input to a double
    r = stod(input);

    // Calculate area and volume
    // Ensure floating-point division instead of integer division by
    // explicitly writing 4.0/3.0
    A = 4.0 * pi * r * r;
    V = (4.0/3.0) * pi * r * r * r;

    // Write out result
    cout << "Sphere radius: " << r << endl;
    cout << "Sphere area:   " << A << endl;
    cout << "Sphere volume: " << V << endl;

    // Return success
    return 0;
}

/*
 * Solution to Exercise 3.1
 *
 * Corrected version of given code.
 *
 */

#include <iostream>     // missing # and < >
using namespace std;    // need to add this, or prefix 'cout' and 'endl' with
                        // 'std::'

int main()              // missing 'int', needs to be 'main' not 'Main', no ;
{
    float x,y,z;        // lowercase 'f'
    x = 2;
    y=3;
    z = x + y;          // missing ;
    cout << "Result is " << z << endl;   // Need << instead of < before z,
                                         // 'endl' instead of 'end'
    return 0;           // should be integer 0, not 0., missing ;
}

